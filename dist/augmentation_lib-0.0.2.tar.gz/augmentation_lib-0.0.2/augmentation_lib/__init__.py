VERSION = (0, 0, 2)
__version__ = '.'.join([str(x) for x in VERSION])
