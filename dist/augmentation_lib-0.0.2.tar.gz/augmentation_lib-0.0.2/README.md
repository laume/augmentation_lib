# Image augmentation library

This augmentation library can be used to crop, flip, blur, sharpen, mix channels, overlay images.