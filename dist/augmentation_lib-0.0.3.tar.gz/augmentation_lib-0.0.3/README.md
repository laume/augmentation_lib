#Image augmentation library

This image augmentation library can be used to crop, flip, blur, sharpen, mix channels, overlay images.
The main idea is to use only numpy library to perform this tasks.

#Getting it

To download augmentation_lib, either fork this github repo or simply use Pypi via pip.
$ pip install augmentation-lib

#Using it

